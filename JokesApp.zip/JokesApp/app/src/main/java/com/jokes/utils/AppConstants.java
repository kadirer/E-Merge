package com.jokes.utils;

public class AppConstants {
    public static final String RANDOM_JOKES_URL = "https://api.chucknorris.io/jokes/random";
    public static final String CATEGORIES_URL = "https://api.chucknorris.io/jokes/categories";
    public static final String JOKES_BY_CATEGORIES_URL = "https://api.chucknorris.io/jokes/random?category=";
}

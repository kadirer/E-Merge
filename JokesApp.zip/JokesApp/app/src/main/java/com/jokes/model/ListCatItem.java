package com.jokes.model;

public class ListCatItem {

    String catName;

    public ListCatItem(String catName) {
        this.catName = catName;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }
}

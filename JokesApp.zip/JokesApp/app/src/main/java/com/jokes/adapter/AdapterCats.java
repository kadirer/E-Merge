package com.jokes.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.jokes.jokesapp.R;
import com.jokes.model.ListCatItem;
import com.jokes.network.AdapterCallback;
import java.util.ArrayList;


public class AdapterCats extends RecyclerView.Adapter<AdapterCats.ViewHolder> {

    private Context context;
    private ArrayList<ListCatItem> listItems;
    AdapterCallback callback;

    public AdapterCats(Context context, ArrayList<ListCatItem> listItem, AdapterCallback callback) {
        this.context = context;
        this.listItems = listItem;
        this.callback = callback;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_categories, parent, false);
        return new ViewHolder(v, context, (ArrayList<ListCatItem>) listItems);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Object jokeCategory = listItems.get(position);
        String catName = ((String)jokeCategory).substring(0, 1).toUpperCase() + ((String)jokeCategory).substring(1);
        holder.name.setText(catName);
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView name;

        public ViewHolder(View view, Context ctx, ArrayList<ListCatItem> items) {
            super(view);
            listItems = items;
            //get the Activity Context
            context = ctx;
            view.setOnClickListener(this);
            name = (TextView) view.findViewById(R.id.cat_name);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            if(position != RecyclerView.NO_POSITION) {
                Object listCatItem = listItems.get(position);
                callback.selectedCategory((String) listCatItem);
            }
        }
    }
}



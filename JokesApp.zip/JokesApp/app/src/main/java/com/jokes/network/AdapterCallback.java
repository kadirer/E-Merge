package com.jokes.network;

public interface AdapterCallback
{
    void selectedCategory(String url);
}

package com.jokes.jokesapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.jokes.adapter.AdapterCats;
import com.jokes.model.ListCatItem;
import com.jokes.network.AdapterCallback;
import com.jokes.utils.AppUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.jokes.utils.AppConstants.CATEGORIES_URL;
import static com.jokes.utils.AppConstants.JOKES_BY_CATEGORIES_URL;
import static com.jokes.utils.AppConstants.RANDOM_JOKES_URL;

public class MainActivity extends AppCompatActivity implements AdapterCallback {

    public static final String TAG = "---> JOKES ";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private ArrayList<ListCatItem> listItems;
    private LinearLayout mJokesView, progressBar, randomJokeView;
    private TextView loadingText;
    private RequestQueue queue;
    private StringRequest stringRequest;
    private TextView jokeCategoryText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getAllIDs();

        //Fetch random joke
        getJoke(RANDOM_JOKES_URL);
    }

    private void getAllIDs() {
        progressBar = findViewById(R.id.progressBar);
        randomJokeView = findViewById(R.id.random_joke_view);
        loadingText = findViewById(R.id.loading_text);
        jokeCategoryText = findViewById(R.id.joke_category);
        mJokesView = findViewById(R.id.jokes_view);
        recyclerView = findViewById(R.id.recycler_cats_list);
        recyclerView.setHasFixedSize(true);
        //every item has a fixed size
        recyclerView.setLayoutManager(new
                LinearLayoutManager(this));
        queue = Volley.newRequestQueue(getApplicationContext());
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (queue != null) {
            queue.cancelAll(TAG);
        }
    }

    public void getJoke(String URL) {
        //Handle view hide/visible states
        randomJokeView.setVisibility(View.GONE);
        loadingText.setVisibility(View.VISIBLE);

        stringRequest = new StringRequest(Request.Method.GET, URL,
                response -> {
                    randomJokeView.setVisibility(View.VISIBLE);
                    loadingText.setVisibility(View.GONE);
                    if (!URL.contains("category")) {
                        getCategories();
                    }
                    try {
                        JSONObject randomJokesJson = new JSONObject(response);
                        ((TextView) findViewById(R.id.created_at)).setText("CREATED AT : " + randomJokesJson.getString("created_at"));
                        ((TextView) findViewById(R.id.icon_url)).setText("ICON URL : " + randomJokesJson.getString("icon_url"));
                        ((TextView) findViewById(R.id.id)).setText("ID : " + randomJokesJson.getString("id"));
                        ((TextView) findViewById(R.id.updated_at)).setText("UPDATED AT : " + randomJokesJson.getString("updated_at"));
                        ((TextView) findViewById(R.id.url)).setText("URL : " + randomJokesJson.getString("url"));
                        ((TextView) findViewById(R.id.value)).setText("VALUE : " + randomJokesJson.getString("value"));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }
                }, error -> AppUtils.showToast(getApplicationContext(), "Error in response!  "));

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    public void getCategories() {
        stringRequest = new StringRequest(Request.Method.GET, CATEGORIES_URL,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    mJokesView.setVisibility(View.VISIBLE);
                    try {
                        JSONArray jsonCatsArray = new JSONArray(response);
                        Log.d(TAG, jsonCatsArray.toString());
                        listItems = new Gson().fromJson(String.valueOf(jsonCatsArray), ArrayList.class);
                        adapter = new AdapterCats(getApplicationContext(), listItems, MainActivity.this);
                        recyclerView.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }
                }, error -> AppUtils.showToast(getApplicationContext(), "Error in response! "));

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    @Override
    public void selectedCategory(String categoryName) {
        jokeCategoryText.setText(categoryName.toUpperCase() + " Chuck Joke :");
        getJoke(JOKES_BY_CATEGORIES_URL + categoryName);
    }
}